import { Account } from "./types";

export const accounts: Account[] = []